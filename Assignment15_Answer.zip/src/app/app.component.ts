import { Component } from '@angular/core';

// import classes which are required for reactive forms
import {FormBuilder,FormGroup,Validators, FormControl, MinLengthValidator} from '@angular/forms'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent 
{
  // Inject FormBuilder service
  constructor(public fbobj : FormBuilder)
  {
  }

  MarvellousForm = this.fbobj.group(
    {
      // Add Multiple validations
      firstName :['', [Validators.required, Validators.minLength(5)] ],
      lastName :['', [Validators.required, Validators.minLength(5)] ],

      //Validaiton
      //email : ['',Validators.required, Validators.pattern("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,4}$")],
      //phone : ['',Validators.pattern('[6-9]\\d{9}'), Validators.maxLength(10)],

      email : ['',Validators.required],
      phone : ['',Validators.pattern('[6-9]\\d{9}')],
      address : [''],
      MarvellousClass : this.fbobj.group(
        { }
      )
    }
  );
  
  // Method to set FormControl fields through program
 /* SetData()

    
    , Validators.maxLength(10)


  {
    this.MarvellousForm.setValue(
      {
        username : 'Piyush',
        passowrd : 'abcd',
        ConfirmPass :  'abcd',
        MarvellousClass : 
        {
          batch : 'Python',
          fees : '5000'
        }
      }
    )
  }
  */
}
