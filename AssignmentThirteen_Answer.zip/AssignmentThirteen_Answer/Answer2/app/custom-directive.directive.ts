import { Directive, ElementRef, Input, AfterViewInit, ViewChild} from '@angular/core';

@Directive({
  selector: '[appCustomDirective]'
})
export class CustomDirectiveDirective implements AfterViewInit {
  @Input() tcolor: string = "";  
  @Input() bcolor: string = "";  
  @Input() tsize: string = "";   
  constructor(private _eobj:ElementRef) { }

  ngAfterViewInit(): void {  
    this.tcolor = (this.tcolor || 'Black');
    this.bcolor = this.bcolor || 'yellow';  
    this.tsize = this.tsize || '60px';  
    this._eobj.nativeElement.style.color = this.tcolor; 
    this._eobj.nativeElement.style.backgroundColor = this.bcolor;  
    this._eobj.nativeElement.style.fontSize = this.tsize;
    this._eobj.nativeElement.style.fontWeight = "bold";  
 }
}
