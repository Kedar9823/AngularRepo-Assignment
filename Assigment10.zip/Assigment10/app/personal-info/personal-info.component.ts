import { Component, OnInit } from '@angular/core';
import { FormBuilder,FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'app-personal-info',
  templateUrl: './personal-info.component.html',
  styleUrls: ['./personal-info.component.css']
})
export class PersonalInfoComponent {
  // Inject FormBuilder service
  constructor(public fbobj : FormBuilder)
  {
  }

  BugForm = this.fbobj.group(
    {
      // Add Multiple validations
      username :['', [Validators.required, Validators.minLength(5)] ],
      Lastname : ['',Validators.required],
      email : ['',Validators.email]
    }
  );
  
  // Method to set FormControl fields through program
  SetData()
  {
    this.BugForm.setValue(
      {
        username : 'Piyush',
        passowrd : 'abcd',
        ConfirmPass :  'abcd',
        MarvellousClass : 
        {
          batch : 'Python',
          fees : '5000'
        }
      }
    )
  }
}
